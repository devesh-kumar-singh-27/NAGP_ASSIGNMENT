package com.nagarro.urban.zuul;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RoutingInformation {
}
